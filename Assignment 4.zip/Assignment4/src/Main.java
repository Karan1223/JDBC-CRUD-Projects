
public class Main //Main class
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Staff staff = new Staff();  //creating a object and calling the constructor

	}

}


/*
/*************************************************************************************************
*  Course_Name � Assignment x                                                                                                                                *

*  I declare that this assignment is my own work in accordance with Humber Academic Policy.        *

*  No part of this assignment has been copied manually or electronically from any other source       *

*  (including web sites) or distributed to other students/social media.                                                       *
                                                                                                                                                                             
*  Name: Karan Punjabi and Richu Thankachan Student ID: N01514624 & N01516068 Date: 05-07-2022 
*/