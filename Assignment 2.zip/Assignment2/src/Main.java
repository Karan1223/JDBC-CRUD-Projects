
public class Main 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Customer c = new Customer(); //Just a simple constructor of Customer Class.

	}

}
